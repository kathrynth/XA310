Pizza Generator

Outline your pseudocode in this document, as well as your explanation of the
function and a description of how you would update the code for varying prices. 

Also list any issues you experienced, other people you may have worked
with, or any other information that seems relevant about this assignment.

----------------