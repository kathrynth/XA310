Please write your pseudocode for each challenge below; also include any
write-up of your process, issues you faced, any tutorials or resources you
used, and so on.

----------




